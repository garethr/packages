#!/bin/bash

echo "example.1 42"
echo "example.2 24"
